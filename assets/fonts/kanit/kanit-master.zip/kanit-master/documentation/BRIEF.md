#Kanit Font

The objective of this project is to design a formal Loopless Thai and Sans Latin typeface. Therefore, Kanit is a flexible family of modern sans serif that is characterized by humanistic and capsule curve of geometric. The family consists of 9 weights, ranging from Thin to Black with matching italics. For further development, this typeface can be extended the family to narrow and extended version or match with other non-Latin script.
